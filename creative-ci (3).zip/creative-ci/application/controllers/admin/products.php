<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class products extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$admin = $this->session->userdata('admin');
		if (empty($admin)){
			$this->session->set_flashdata('msg','please login');
			redirect(base_url().'admin/login/index');
			}
		}

	public function index($page=1)
	{
		$perpage = 10;
		$param['offset'] = $perpage;
		$param['limit'] = ($page*$perpage)-$perpage;
		$param['q'] =$this->input->get('q');

		$this->load->model('Product_model');
		$this->load->library('pagination');
		$config['base_url'] = base_url('admin/products/index');
		$config['total_rows'] = $this->Product_model->getProductsCount($param);
		$config['per_page'] = $perpage;
		$config['use_page_numbers'] = true;

		//pagination next prev designs
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$config['full_tag_open'] = "<ul class='pagination'>";
		$config['full_tag_close'] = "</ul>";
		$config['num_tag_open'] = '<li class="page-item">';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='disabled page-item'><li class='active page-item'><a href='#' class=\"page-link\">";
		$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] = "<li class=\"page-item\">";
		$config['next_tagl_close'] = "</li>";
		$config['prev_tag_open'] = "<li class=\"page-item\">";
		$config['prev_tagl_close'] = "</li>";
		$config['first_tag_open'] = "<li class=\"page-item\">";
		$config['first_tagl_close'] = "</li>";
		$config['last_tag_open'] = "<li class=\"page-item\">";
		$config['last_tagl_close'] = "</li>";
		$config['attributes'] = array('class' => 'page-link');

		$this->pagination->initialize($config);
		$pagination_links = $this->pagination->create_links();

		$products=$this->Product_model->getProducts($param);

		$data['q'] =$this->input->get('q');
		$data['products']=$products;
		$data['pagination_links']=$pagination_links;
		//print_r($products);
		$this->load->view('admin/products/list',$data);		
	}

	public function create()
	{
		$this->load->model('Product_model');
		// File Upload Settings
		$config['upload_path'] = './public/uploads/products/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = true;

		$this->load->library('upload',$config);

		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="invalid feedback">','</p>');
		$this->form_validation->set_rules('pname','Product Name', 'trim|required');
		$this->form_validation->set_rules('pdescription','Product Description', 'trim|required');

		if ($this->form_validation->run() == true) {
			// Form validation successfull
			
			if (!empty($_FILES['image']['name'])) {
				//Here we will save Images
				if ($this->upload->do_upload('image')) {
					// Image successfully uploaded here...
					$data= $this->upload->data();
					//
					$formArray['image'] = $data['file_name'];
					$formArray['pname'] = $this->input->post('pname');
					$formArray['pdescription'] = $this->input->post('pdescription');
					$formArray['status'] = $this->input->post('status');
					$formArray['created_at'] = date('Y-m-d H:i:s');
					$this->Product_model->addProduct($formArray);

					$this->session->set_flashdata('success', 'Product Added Successfully');
					redirect(base_url().'admin/products/index');
					
				} else {
					// Selected image has some errors
					$errors = $this->upload->display_errors('<p class="invalid-feedback">', '</p>');	
					$data['imageError'] = $errors;
					$this->load->view('admin/products/create', $data);
				}
				
			} else {
				// here we will savw product without Image...
				$formArray['pname'] = $this->input->post('pname');
				$formArray['pdescription'] = $this->input->post('pdescription');
				$formArray['status'] = $this->input->post('status');
				$formArray['created_at'] = date('Y-m-d H:i:s');
				$this->Product_model->addProduct($formArray);
				redirect(base_url().'admin/products/index');
			}
			
		} else {
			// Form Not validated can show errors
		}
		


		$this->load->view('admin/products/create');
	}

	public function edit($id)
	{
		$this->load->model('Product_model');
		$products = $this->Product_model->getProduct($id);
		if (empty($products)) {
			$this->session->set_flashdata('error', 'Product Not Found');
			redirect(base_url('admin/products/index'));
		}

		$data['products'] = $products;


		// File Upload Settings
		$config['upload_path'] = './public/uploads/products/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = true;

		$this->load->library('upload',$config);

		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="invalid feedback">','</p>');
		$this->form_validation->set_rules('pname','Product Name', 'trim|required');
		$this->form_validation->set_rules('pdescription','Product Description', 'trim|required');

		if ($this->form_validation->run() == true) {
			// Form validation successfull
			
			if (!empty($_FILES['image']['name'])) {
				//Here we will save Images
				if ($this->upload->do_upload('image')) {
					// Image successfully uploaded here...
					$data= $this->upload->data();

					$path= './public/uploads/products/'.$products['image'];
                      if ($products['image'] != "" && file_exists($path)) {
                      	unlink($path); //this method will remove old image in upload/products folder
                      }
					//
					$formArray['image'] = $data['file_name'];
					$formArray['pname'] = $this->input->post('pname');
					$formArray['pdescription'] = $this->input->post('pdescription');
					$formArray['status'] = $this->input->post('status');
					$formArray['updated_at'] = date('Y-m-d H:i:s');
					$this->Product_model->updateProduct($id,$formArray);

					$this->session->set_flashdata('success', 'Product Updated Successfully');
					redirect(base_url().'admin/products/index');
					
				} else {
					// Selected image has some errors
					$errors = $this->upload->display_errors('<p class="invalid-feedback">', '</p>');	
					$data['imageError'] = $errors;
					$this->load->view('admin/products/edit', $data);
				}
				
			} else {
				// here we will savw product without Image...
				$formArray['pname'] = $this->input->post('pname');
				$formArray['pdescription'] = $this->input->post('pdescription');
				$formArray['status'] = $this->input->post('status');
				$formArray['updated_at'] = date('Y-m-d H:i:s');
					$this->Product_model->updateProduct($id,$formArray);
				redirect(base_url().'admin/products/index');
			}
			
		} else {
			// Form Not validated can show errors
			$this->load->view('admin/products/edit', $data);
		}

		//print_r($product);
		//echo $id;
	}

	public function delete($id)
	{
		$this->load->model('Product_model');
		$products = $this->Product_model->getProduct($id);
		if (empty($products)) {
			$this->session->set_flashdata('error', 'Product not found');
			redirect(base_url('admin/products/index'));
		}
		$path= './public/uploads/products/'.$products['image'];
                      if ($products['image'] != "" && file_exists($path)) {
                      	unlink($path); //this method will remove old image in upload/products folder
                      }

		$this->Product_model->deleteProduct($id); //this will delete product
		$this->session->set_flashdata('success', 'Product Deleted Successfully');
					redirect(base_url().'admin/products/index');
	}
}

?>