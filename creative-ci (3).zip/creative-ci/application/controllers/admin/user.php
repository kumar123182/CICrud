<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class user extends CI_Controller {

    function create(){
        $this->load->model('User_model');
        $this->form_validation->set_rules('name', 'Name', 'required'); 
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[user.email]'); 
        $this->form_validation->set_rules('phone', 'phone', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if($this->form_validation->run() == false){
            $this->load->view('admin/register');
        } else {
            $formArray = array();
            $formArray['name'] = $this->input->post('name');
            $formArray['email'] = $this->input->post('email');
            $formArray['phone'] = $this->input->post('phone');
            $formArray['address'] = $this->input->post('address');
            $formArray['password'] = password_hash($this->input->post('password'),PASSWORD_DEFAULT);

            $this->User_model->create($formArray);
            $this->session->set_flashdata('success','User Registerd Successfully');

             redirect(base_url().'admin/login');
        }
    } 
}

?>