<?php $this->load->view('admin/header') ?>
<!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Products</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url(). 'admin/products/index' ?>">Products</a></li>
              <li class="breadcrumb-item active">Create New Products</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card card-primary">
                <div class="card-header">
	            	<div class="card-title">
	            		Create New products
	            	</div>
                </div>
            <form enctype="multipart/form-data" name="productsForm" id="productsForm" method="post" action="<?php echo base_url(). 'admin/products/create' ?>">

                <div class="card-body">
                		<div class="form-group">
                			<label>Product Name</label>
                			<input type="text" name="pname" id="pname" value="<?php echo set_value('pname'); ?>" class="form-control <?php echo (form_error('pname')!="") ? 'is-invalid' : ''; ?>">
                			<?php echo form_error('pname'); ?>
                		</div>

                    <div class="form-group">
                      <label>Product Description</label>
                      <textarea name="pdescription" id="pdescription" value="" class="form-control <?php echo (form_error('pdescription')!="") ? 'is-invalid' : ''; ?>"> <?php echo set_value('pdescription'); ?> </textarea>
                      <?php echo form_error('pdescription'); ?>
                    </div>

                		<div class="form-group">
                			<label>Product Image</label>
                			<input type="file" name="image" id="image" value="" class="<?php echo (!empty($imageError)) ? 'is-invalid' : ''; ?>">
                      <?php if(!empty($imageError)) echo  $imageError; ?>
                		</div>
                		<div class="custom-control custom-radio float-left">
                			<input type="radio" name="status" class="custom-control-input" value="1" id="statusActive" checked="">
                			<label for="statusActive" class="custom-control-label">Active</label>
                		</div>
                		<div class="custom-control custom-radio float-left ml-3">
                			<input type="radio" name="status" class="custom-control-input" value="0" id="statusBlock">
                			<label for="statusBlock" class="custom-control-label">Block</label>
                		</div>
                	
                </div>
	                <div class="card-footer">
	                	<button name="submit" type="submit" class="btn btn-primary">Submit</button>
	                	<a href="<?php echo base_url(). 'admin/products/index' ?>" class="btn btn-secondary">Back</a>
	                </div>
	         </form>
              </div>
            
            </div>

           
          </div>
          <!-- /.col-md-6 -->
          
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('admin/footer') ?>
