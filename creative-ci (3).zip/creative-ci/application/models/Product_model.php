<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class Product_model extends CI_Model{ 
    function getProduct($id)
    {
        $this->db->where('id', $id);
        $query= $this->db->get('products');
        $product = $query->row_array();
        //SELECT * FROM products WHERE id=(YourProductId)
        return $product;
    }

    function getProducts($param = array())
    {

       if (isset($param['offset']) && isset($param['limit'])) {
           $this->db->limit($param['offset'],$param['limit']);
       }

       if(isset($param['q'])){
            $this->db->or_like('pname',trim($param['q']));
            $this->db->or_like('pdescription',trim($param['q']));
       }

       $query = $this->db->get('products'); 

       //echo $this->db->last_query();

       $products = $query->result_array();
       return $products;
    }

    function getProductsCount($param = array()) {

       if(isset($param['q'])){
        $this->db->or_like('pname',trim($param['q']));
        $this->db->or_like('pdescription',trim($param['q']));
       }
    {
       $count = $this->db->count_all_results('products'); 
       return $count;
    }
    }
    function addProduct($formArray)
    {
        $this->db->insert('products', $formArray);
        return $this->db->insert_id();
    }

    function updateProduct($id,$formArray)
    {
        $this->db->where('id',$id);
       $this->db->update('products', $formArray);
    }

    function deleteProduct($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('products');
    }

    
}

?>