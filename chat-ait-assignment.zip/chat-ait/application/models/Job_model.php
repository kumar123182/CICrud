<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class Job_model extends CI_Model{ 
    function getJob($id)
    {
        $this->db->where('id', $id);
        $query= $this->db->get('job_table');
        $job = $query->row_array();
        //SELECT * FROM job_table WHERE id=(YourJobtId)
        return $job;
    } 

    function getInbox($jobInbox)
    {
        $this->db->where('job_title', $jobInbox);
        $query= $this->db->get('job_table');
        $inbox = $query->row_array();
        //SELECT * FROM job_table WHERE id=(YourJobtId)
        return $inbox;
    }
    function getContact($jobContact)
    {
        $this->db->where('user_name', $jobContact);
        $query= $this->db->get('job_table');
        $contact = $query->row_array();
        //SELECT * FROM job_table WHERE id=(YourJobtId)
        return $contact;
    }

    function getJobs($param = array())
    {

       if (isset($param['offset']) && isset($param['limit'])) {
           $this->db->limit($param['offset'],$param['limit']);
       }

       if(isset($param['q'])){
            $this->db->or_like('job_title',trim($param['q']));
            $this->db->or_like('description',trim($param['q']));
       }
        $this->db->order_by("id", "desc");
       $query = $this->db->get('job_table'); 

       //echo $this->db->last_query();

       $jobs = $query->result_array();
       return $jobs;
    }

    function getJobsCount($param = array()) {

       if(isset($param['q'])){
        $this->db->or_like('job_title',trim($param['q']));
        $this->db->or_like('description',trim($param['q']));
       }
    {
       $count = $this->db->count_all_results('job_table'); 
       return $count;
    }
    }
    function addJob($formArray)
    {
        $this->db->insert('job_table', $formArray);
        return $this->db->insert_id();
    }

    function updateJob($id,$formArray)
    {
        $this->db->where('id',$id);
       $this->db->update('job_table', $formArray);
    }

    function deleteJob($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('job_table');
    }  

    function addChat($formArray)
    {
        $this->db->insert('chat', $formArray);
        return $this->db->insert_id();
    }

}

?>