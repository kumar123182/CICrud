<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Job extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$admin = $this->session->userdata('admin');
		if (empty($admin)){
			$this->session->set_flashdata('msg','please login');
			redirect(base_url().'admin/login/index');
			}
		}

	public function index($page=1)
	{
		$perpage = 5;
		$param['offset'] = $perpage;
		$param['limit'] = ($page*$perpage)-$perpage;
		$param['q'] =$this->input->get('q');

		$this->load->model('Job_model');
		$this->load->library('pagination');
		$config['base_url'] = base_url('admin/job/index');
		$config['total_rows'] = $this->Job_model->getJobsCount($param);
		$config['per_page'] = $perpage;
		$config['use_page_numbers'] = true;

		//pagination next prev designs
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$config['full_tag_open'] = "<ul class='pagination'>";
		$config['full_tag_close'] = "</ul>";
		$config['num_tag_open'] = '<li class="page-item">';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='disabled page-item'><li class='active page-item'><a href='#' class=\"page-link\">";
		$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] = "<li class=\"page-item\">";
		$config['next_tagl_close'] = "</li>";
		$config['prev_tag_open'] = "<li class=\"page-item\">";
		$config['prev_tagl_close'] = "</li>";
		$config['first_tag_open'] = "<li class=\"page-item\">";
		$config['first_tagl_close'] = "</li>";
		$config['last_tag_open'] = "<li class=\"page-item\">";
		$config['last_tagl_close'] = "</li>";
		$config['attributes'] = array('class' => 'page-link');

		$this->pagination->initialize($config);
		$pagination_links = $this->pagination->create_links();

		$jobs=$this->Job_model->getJobs($param);

		$data['q'] =$this->input->get('q');
		$data['jobs']=$jobs;
		$data['pagination_links']=$pagination_links;
		//print_r($jobs);
		$this->load->view('admin/jobs/list',$data);		
	}

	public function create()
	{
		$this->load->model('Job_model');
		$this->load->model('Admin_model');
		
		$users = $this->Admin_model->getUsers();
		$data['users'] = $users;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="invalid feedback">','</p>');
		$this->form_validation->set_rules('job_title','Jon Title', 'trim|required');
		$this->form_validation->set_rules('description','Job Description', 'trim|required');
		$this->form_validation->set_rules('username','User Name', 'trim|required');

		if ($this->form_validation->run() == true) {
			// Form validation successfull
				$formArray['job_title'] = $this->input->post('job_title');
				$formArray['description'] = $this->input->post('description');
				$formArray['user_name'] = $this->input->post('username');
				$formArray['submission_time'] = date('Y-m-d H:i:s');
				$this->Job_model->addJob($formArray);
				redirect(base_url().'admin/job/index');
			
		} else {
			// Form Not validated can show errors
		}
		$this->load->view('admin/jobs/create', $data);
	}

	public function edit($id)
	{
		$this->load->model('Job_model');
		$jobs = $this->Job_model->getJob($id);
		if (empty($jobs)) {
			$this->session->set_flashdata('error', 'Jobs list Not Found');
			redirect(base_url('admin/job/index'));
		}

		$data['jobs'] = $jobs;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="invalid feedback">','</p>');
		$this->form_validation->set_rules('job_title','Job Name', 'trim|required');
		$this->form_validation->set_rules('description','Job Description', 'trim|required');

		if ($this->form_validation->run() == true) {
			// Form validation successfull
			
			$formArray['job_title'] = $this->input->post('job_title');
			$formArray['description'] = $this->input->post('description');
			$this->Job_model->updateJob($id,$formArray);
			redirect(base_url().'admin/job/index');
			
		} else {
			// Form Not validated can show errors
		}
		$this->load->view('admin/jobs/edit', $data);
		//print_r($jobs);
		//echo $id;
	}

	public function delete($id)
	{
		$this->load->model('Job_model');
		$jobs = $this->Job_model->getJob($id);
		if (empty($jobs)) {			
			$this->session->set_flashdata('error', 'Job List not found');
			redirect(base_url('admin/jobs/index'));
		}
		

		$this->Job_model->deleteJob($id); //this will delete product
		$this->session->set_flashdata('success', 'Job Deleted Successfully');
					redirect(base_url().'admin/job/index');
	}

	public function inbox($jobInbox){
		$this->load->model('Job_model');
		$inbox = $this->Job_model->getInbox($jobInbox);
		if (empty($inbox)) {
			$this->session->set_flashdata('error', 'inbox list Not Found');
			redirect(base_url('admin/job/index'));
		}

		$data['inbox'] = $inbox;

		$this->load->view('admin/jobs/inbox', $data);
	}
	public function contact($jobContact){
		$this->load->model('Job_model');
		$contact = $this->Job_model->getContact($jobContact);
		if (empty($contact)) {
			$this->session->set_flashdata('error', 'contact list Not Found');
			redirect(base_url('admin/job/index'));
		}

		$data['contact'] = $contact;

		$this->load->view('admin/jobs/contact', $data);
	}


	public function chat()
	{
		$this->load->model('Job_model');
			$formArray['n_user'] = $this->input->post('user');
			$formArray['msg'] = $this->input->post('msg');			
			$formArray['chat_time'] = date('Y-m-d H:i:s');
			$this->Job_model->addChat($formArray);
			redirect(base_url().'admin/job/contact/'.$this->input->post('user'));

		$this->load->view('admin/jobs/contact');
	}

}

?>