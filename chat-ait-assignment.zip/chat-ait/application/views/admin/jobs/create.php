<?php $this->load->view('admin/header') ?>
<!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Jobs</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url(). 'admin/job/index' ?>">Jobs</a></li>
              <li class="breadcrumb-item active">Create New Job</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card card-primary">
                <div class="card-header">
	            	<div class="card-title">
	            		Create New job
	            	</div>
                </div>
            <form enctype="multipart/form-data" name="jobsForm" id="jobsForm" method="post" action="<?php echo base_url(). 'admin/job/create' ?>">

                <div class="card-body">
                		<div class="form-group">
                			<label>Job Name</label>
                			<input type="text" name="job_title" id="job_title" value="<?php echo set_value('job_title'); ?>" class="form-control <?php echo (form_error('job_title')!="") ? 'is-invalid' : ''; ?>">
                			<?php echo form_error('job_title'); ?>
                		</div>

                    <div class="form-group">
                      <label>Job Description</label>
                      <textarea name="description" id="description" value="" class="form-control <?php echo (form_error('description')!="") ? 'is-invalid' : ''; ?>"> <?php echo set_value('description'); ?> </textarea>
                      <?php echo form_error('description'); ?>
                    </div>

                    <div class="form-group col-md-6">
                        <label>Users</label>
                        <select name="username" id="username" class="form-control <?php echo (form_error('username')!="") ? 'is-invalid' : ''; ?>">
                          <option value="">Select username</option>
                          <?php 
                          print_r($users);
                          if (!empty($users)) {
                            foreach($users as $username){
                              ?>
                              <option <?php echo set_select('username',$username['username'],false);?> value="<?php echo $username['username'];?>"><?php echo $username['username'];?></option>

                              <?php
                              }
                            }
                          ?>
                        </select>
                        <?php echo form_error('username'); ?>
                      </div>	
                	
                </div>
	                <div class="card-footer">
	                	<button name="submit" type="submit" class="btn btn-primary">Submit</button>
	                	<a href="<?php echo base_url(). 'admin/jobs/index' ?>" class="btn btn-secondary">Back</a>
	                </div>
	         </form>
              </div>
            
            </div>

           
          </div>
          <!-- /.col-md-6 -->
          
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    
  <!-- /.content-wrapper -->
<?php $this->load->view('admin/footer') ?>
