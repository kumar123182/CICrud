<?php $this->load->view('admin/header') ?>
<!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Contact Screen</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url(). 'admin/job/index' ?>">Jobs</a></li>
              <li class="breadcrumb-item active">"Contact"</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content" style="width:50%; margin-left: 30%;">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card card-primary">
                <div class="card-header">
  	            	<div class="card-title">
  	            		Job Title (<?php echo $contact['job_title'];?>)
  	            	</div>
                </div>
              <?php $user = $contact['user_name']; ?>
                <form enctype="multipart/form-data" name="jobsForm" id="jobsForm" method="post" action="<?php echo base_url(). 'admin/job/chat' ?>">
                  <input type="hidden" name="user" value="<?= $user; ?>">
                  <div class="card-body">
                    <div class="form-group">
                      <textarea name="msg" id="msg" placeholder="Type Your message here!" class="form-control" required></textarea>
                    </div>
                  </div>

                  <div class="card-footer">
                    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>

                <hr>
              <div class="bg-warning"><center><b>Chat</b></center></div>
                <div style="padding: 12px;">
                    <?php                       
                        $this->db->select("*");
                        $this->db->from("chat");
                        $this->db->order_by("id", "desc");
                        $query = $this->db->get();

                        foreach($query->result_array() as $row){
                                          ?>
                    
                  <div class="row col-md-12">
                    <div class="col-md-6 row">
                      <b class="mr-2 usrn"><?= $row['n_user'] ?>:</b>
                      <p class="chat left"><?= $row['msg'] ?></p>
                    </div>
                    
                    <div class="col-md-6 usrn">
                      <p><?= $row['chat_time'] ?></p>
                    </div>
                  </div>
              <?php } ?>
                </div>
              </div>
            
            </div>

           
          </div>
          <!-- /.col-md-6 -->
          
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('admin/footer') ?>
