<?php $this->load->view('admin/header') ?>
<!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Inbox</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url(). 'admin/job/index' ?>">Jobs</a></li>
              <li class="breadcrumb-item active">"Inbox"</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content" style="width:50%; margin-left: 30%;">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card card-primary">
                <div class="card-header">
	            	<div class="card-title">
	            		Job Title (<?php echo $inbox['job_title'];?>)
	            	</div>
                </div>
                <ul>
                  <?php 
                      $jobTitle = $inbox['job_title'];
                      $this->db->select("*");
                      $this->db->from("job_table");
                      $this->db->where('job_title',$jobTitle);
                      $query = $this->db->get();

                      foreach($query->result_array() as $row){
                          echo '<li><a href="'.base_url('admin/job/contact/'.$row['user_name']).'">'.$row['user_name'].'</a></li>';
                      }
                  ?>
                  
                </ul>
              </div>
            
            </div>

           
          </div>
          <!-- /.col-md-6 -->
          
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('admin/footer') ?>
