<?php $this->load->view('admin/header') ?>
<!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Jobs</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Jobs</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
          	<?php if ($this->session->flashdata('success')!= "") { ?>
          	<div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>	
          	<?php } ?>
          	
            <div class="card">
              <div class="card-body">                
                <div class="card-header">
	            	<div class="card-title">
	            		<form id="searchFrm" name="searchFrm" method="get" action="">
	            			<div class="input-group mb-0">
	            				<input type="text" value="<?php echo $q ;?>" class="form-control" placeholder="Search" name="q">
	            				<div class="input-group-append"> 
	            					<button class="input-group-text" id="basic-addon1">
	            						<i class="fas fa-search"></i>
	            					</button>
	            				</div>
	            			</div>
	            		</form>
	            	</div>
	            	<div class="card-tools">
	            		<a href="<?php echo base_url(). 'admin/job/create' ?>" class="btn btn-primary"><i class="fas fa-plus"></i>  Create</a>
	            	</div>
                </div>
                <div class="card-body">
                	<table class="table">
                		<tr>
                			<th width="50">#</th>
                			<th>Job Title</th>
                      <th>User Name</th>
                			<th width="160" class="text-center">Actions</th>
                		</tr>

                    <?php if (!empty($jobs)) { 
                      $i=1;
                      foreach($jobs as $job){
                      ?>

                		<tr>
                			<td><?php echo $i++; ?></td>
                      <td><?php echo $job['job_title']; ?></td>
                			<td><?php echo $job['user_name']; ?></td>
                			<td class="text-center">
                				<a href="<?php echo base_url('admin/job/edit/'.$job['id']); ?>" class="btn btn-primary btn-sm"><i class="far fa-edit"></i> Edit</a>
                				<a href="javascript:void(0);" onclick="deleteJob(<?php echo $job['id']; ?>)" class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i> Delete</a>   
                      <div class="row mt-2">
                        <a href="<?php echo base_url('admin/job/inbox/'.$job['job_title']); ?>" class="btn btn-secondary btn-sm float-left" style="margin-right:3px;"><i class="fa fa-inbox"></i> Inbox</a>
                        <a href="<?php echo base_url('admin/job/contact/'.$job['user_name']) ?>" class="btn btn-warning btn-sm float-right"><i class="fa fa-address-book"></i> Contact</a>    
                      </div>              
                			</td>
                      </tr>
                      <?php } } else { ?>
                		<tr>
                      <td colspan="4">Record Not Found</td>
                    </tr>
                  <?php } ?>
                	</table>

                  <div>
                    <?php echo $pagination_links; ?>
                  </div>
                </div>
              </div>
            </div>

           
          </div>
          <!-- /.col-md-6 -->
          
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('admin/footer') ?>
<script type="text/javascript">
  function deleteJob(id){
   
    if (confirm("are you sure you want to delete Job")) {
      window.location.href='<?php echo base_url().'admin/job/delete/'?>'+id
    }
  }
</script>
