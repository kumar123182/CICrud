-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2022 at 03:03 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `n_user` varchar(100) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `chat_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `n_user`, `msg`, `chat_time`) VALUES
(8, 'user1', 'Hello Raj', '2022-10-20 08:53:39'),
(9, 'user2', 'Hi Shreyansh!', '2022-10-20 08:55:30'),
(10, 'user4', 'Hey User2!', '2022-10-20 09:16:50');

-- --------------------------------------------------------

--
-- Table structure for table `job_table`
--

CREATE TABLE `job_table` (
  `id` int(11) NOT NULL,
  `job_title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `submission_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job_table`
--

INSERT INTO `job_table` (`id`, `job_title`, `description`, `submission_time`, `user_name`) VALUES
(2, 'Job1', 'Job1 Desc', '2022-10-20 03:38:37', 'user1'),
(3, 'Job2', 'job 2', '2022-10-20 08:50:40', 'user2'),
(5, 'Job1', 'descss', '2022-10-20 07:09:16', 'user2'),
(6, 'Job3', 'Job 3 Description', '2022-10-20 09:12:23', 'user4'),
(7, 'Job2', 'job2  Description', '2022-10-20 13:01:51', 'user4'),
(8, 'Job5', 'Job 5 Description here', '2022-10-20 13:01:17', 'user3');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(4, 'user1', '$2y$10$y77BtXRM4dKNUDK/S.nBMusKhDN/TAAjHgX2GooCtBzhQr37QY.fG'),
(5, 'user2', '$2y$10$RwOUFQrPF9ZrjixI26OLHeVrFBPRXtsdMPGs0sKftsfXbuLruIrGO'),
(6, 'user3', '$2y$10$wnaKOve5C3pU9YEcdSBL3uLfQpupW384t8EfGMsQVqLYBsg3mN3Bm'),
(7, 'user4', '$2y$10$CRQ5luL.vXHJYyKsoo8p1OoqxmbSDBzu6WVVrehXWOYeCzmpaVbei');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_table`
--
ALTER TABLE `job_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `job_table`
--
ALTER TABLE `job_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
